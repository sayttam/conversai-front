import { NextResponse } from "next/server"

interface User {
    id: string
    email: string
    name: string
    role: string
    account: string
    clientsAssigned: string[]

}

export async function GET(request: Request) {
  try {
    const accessToken = "JOIA-ostpHLDrZfPPbZ2G4abYPG0JX0Tamv8c2f38Zh1ywi8XZHxUdGh2V5JOsHxd1B6uBpd1CR51wPBtPHqM42ci1AlJM4DQjVkTpt08Xgow7VKWvCYq";
    const response = await fetch("http://localhost:5000/api/campaign", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${accessToken}`,
      },
    })

    const data = await response.json()

    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Login API error:", error)
    return NextResponse.json({ message: "Internal server error FRONT" }, { status: 500 })
  }
}